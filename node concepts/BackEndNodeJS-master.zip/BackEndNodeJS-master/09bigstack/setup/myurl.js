module.exports = {
  mongoURL: "mongodb://hitesh:hitesh@ds161610.mlab.com:61610/lcocourse",
  secret: "mystrongsecret"
};
