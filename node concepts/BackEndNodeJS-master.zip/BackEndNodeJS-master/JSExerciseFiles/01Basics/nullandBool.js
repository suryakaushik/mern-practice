//temp is coming from website API

var temp

//done some calculation
// temp  = 2

console.log("Current temperature is: " + temp)


//Grade system

// 10 - Great job
// 5 - work harder
// 2 - poor
// 0 - fail

//Boolean - true/false

let actualMarks = 10

let myGrade = (actualMarks == 10)

console.log(myGrade)