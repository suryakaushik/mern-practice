let name = 'John'

let score = 100.0
let bonus = 20

let totalScore = score + bonus

console.log(totalScore)

let firstName = 'John'
firstName = 'Jane'


let lastName = 'Doe'

let fullName = firstName + '**'  + lastName

console.log(firstName + '-' + lastName)

console.log(fullName);