var score = 100

score  = 130

const bonus = 50

var finalScore = (score + bonus) * 1.8

var complex = (((4 + 4) * 5) / 2)

// console.log(finalScore)
// console.log(complex)


let tempInFahrenheit = 100

//do calculation
    // (T(°F) - 32) × 5 / 9


let celsius = (tempInFahrenheit - 32) * 5/9



console.log(celsius)