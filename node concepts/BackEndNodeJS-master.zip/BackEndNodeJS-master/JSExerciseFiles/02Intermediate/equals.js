let myVar = {}
let myVarTwo = myVar

console.log({} === {});
console.log(2 === 2.0);
