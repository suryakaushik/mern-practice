console.log('5' + 5);
// const giveType = typeof 

// console.log(giveType)

const adder = 5 + false

//console.log(adder);


const loginDetials = ''
//login for getting details from DB

const loginID = loginDetials[0]

if (loginDetials) {
    console.log('Allow user to login');
    
} else {
    console.log('Auth failed');
    
}

// Values that interpret as false: 
// false
// 0
// ''
// null
// undefined