import React from 'react';
import Products from '../components/Products';

const ProductsPage = () => {
    return (
        <div>
            <Products />
        </div>
    )
}

export default ProductsPage;
