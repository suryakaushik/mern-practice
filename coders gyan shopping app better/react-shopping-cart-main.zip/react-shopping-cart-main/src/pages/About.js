const About = () => {
    return (
        <h1>Hello from About page</h1>
    )
}

export default About;

